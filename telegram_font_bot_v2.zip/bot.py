import telebot
from fonts import stylize_all
from config import TOKEN, ADMIN_ID

bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start'])
def start(message):
    bot.send_message(message.chat.id, "Привет! Отправь мне текст, и я преобразую его в красивые стили.")

@bot.message_handler(commands=['stats'])
def stats(message):
    if str(message.from_user.id) == ADMIN_ID:
        bot.send_message(message.chat.id, "Админ-команда: Пока статистика не собирается.")
    else:
        bot.send_message(message.chat.id, "Команда недоступна.")

@bot.message_handler(func=lambda message: True, content_types=['text'])
def stylize_text(message):
    text = message.text.strip()
    styles = stylize_all(text)
    reply = "\n\n".join(styles)
    bot.send_message(message.chat.id, reply)

bot.infinity_polling()