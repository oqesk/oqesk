# Telegram Бот с Красивыми Шрифтами

## Запуск на Railway
1. Создай аккаунт: https://railway.app
2. Нажми "New Project" → "Deploy from GitHub" или "Deploy from template".
3. Загрузите файлы проекта.
4. Railway автоматически установит зависимости и запустит бота.

## Локальный запуск
```bash
pip install -r requirements.txt
python bot.py
```

## Команды
- /start — Приветствие
- /stats — Только для админа (ваш ID)
- Просто отправь текст — и бот покажет стили